export class Activitycount {
    activityDate: Date;
    countTotal: number

    constructor(activityDate: Date, countTotal: number) {
        this.activityDate = activityDate;
        this.countTotal = countTotal;
    }
    
}
