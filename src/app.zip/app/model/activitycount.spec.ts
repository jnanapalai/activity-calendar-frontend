import { Activitycount } from './activitycount';

describe('Activitycount', () => {
  it('should create an instance', () => {
    expect(new Activitycount()).toBeTruthy();
  });
});
