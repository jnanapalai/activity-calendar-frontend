import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { CreateactivityComponent } from './activity/createactivity/createactivity.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ShowactivityComponent } from './activity/showactivity/showactivity.component';
import { AllactivityComponent } from './activity/allactivity/allactivity.component';
import { HttpClientModule } from '@angular/common/http';
import { MonthcalendarComponent } from './activity/monthcalendar/monthcalendar.component';

const routes = [
  {path:"createActivity",component:CreateactivityComponent}
  
]

@NgModule({
  declarations: [
    AppComponent,
    CreateactivityComponent,
    ShowactivityComponent,
    AllactivityComponent,
    MonthcalendarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
