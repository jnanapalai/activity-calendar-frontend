import { Component } from '@angular/core';

@Component({
  selector: 'app-monthcalendar',
  templateUrl: './monthcalendar.component.html',
  styleUrl: './monthcalendar.component.css'
})
export class MonthcalendarComponent {

}
