import { HttpClient,HttpParams } from '@angular/common/http';
import { Injectable} from '@angular/core';
import { Activity } from '../model/activity';
import { Activitycount } from '../model/activitycount';

@Injectable({
  providedIn: 'root'
})
export class ActivityService  {

  
  constructor(private httpCleint: HttpClient) { }

  getListOfActivities() {
    return this.httpCleint.get<Activity[]>("/api/activity");  
  }

  getListActivitiesByDate(clickedDate: any) {
     let params = new HttpParams().set('activityDate', clickedDate);
    return this.httpCleint.get<Activity[]>("/api/activity", {params: params});
  }

  createActivity(activity: Activity) {
    return this.httpCleint.post("/api/activity", activity);
    
  }

  countListActivityByActivityDate() {
    return this.httpCleint.get<Activitycount[]>("/api/activity/count");
  }

  completeActivity(activityId: number) {
    let params = new HttpParams
    return this.httpCleint.patch('/api/activity/'+activityId+'/complete','');       
  }

  deleteActivity(activityId: number) {
    return this.httpCleint.delete("/api/activity/"+activityId);
  }

}
